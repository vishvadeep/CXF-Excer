package com.cap.rest;

import static io.restassured.RestAssured.get;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.BeforeClass;
import org.junit.Test;

import io.restassured.RestAssured;

public class RestControllerTest {
	 @BeforeClass
	    public static void init() {
	        RestAssured.baseURI = "http://localhost";
	        RestAssured.port = 8080;
	    }
	 
	 

	    @Test
	    public void testUserFetchesSuccess() {
	   //     System.out.println(get("/camel-prime-fact/services/primeService/fact/4"));
	    	get("/camel-prime-fact/services/primeService/fact/5")
	        .then()
	        .body(containsString("120"));
	       
	    }
	    
}
