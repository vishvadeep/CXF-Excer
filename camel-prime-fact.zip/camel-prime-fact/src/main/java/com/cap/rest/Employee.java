package com.cap.rest;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {

	String name;
	String add;
	Employee(){
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", add=" + add + "]";
	}
	
	
}
