package com.cap.rest;




import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import org.springframework.stereotype.Service;

@Service("servicebean")
//@Path("/primeService")
public class RestController  implements IRestController{

	
	
	public void addform( String name, String pass) {
		
		System.out.println("you are in add form");
	}
	public String add(Employee e)
	{
		System.out.println("employee " +e);
		return "success "+e;
	}
	
	public int factCalculate( int id) 
	{
	int fact = calcuate(id);
		
		return fact;
	}
	 
	public String primeCalculate(@PathParam("id") int id) {
		boolean flag=true;
		String  value;
	    for (int i=2; i<id; i++)  
	    {
	    	if (id%i==0) {
	    		flag = false;
	    	}
	    }
	    if (flag) {
	    	value="this is a prime number";
		return value;
	    }
	    else {
	    	value="this is not a prime number";
	    	return value;
	    }
	}
	
	public int calcuate(int i) {
		int n=1;
		System.out.println("i value"+i);
		for(int j=i; j>=1; j--) {
			System.out.println("j=="+j);
			n=n*j;
			System.out.println("n value"+n);
		}
		System.out.println("n value"+n);
		return n;
	}

	public Employee  get( int id) {
		
		System.out.println("a "+id);
		Employee e = new Employee();
		e.setName("vishvaeep");
		e.setAdd("pune");
		return e;
		
	//	return "hello int";
		
	}
	
	 
	    public String getPlayerInfo(@PathParam("id") int playerId) {
	    	
	    	return "hello";
	    }

	 
	
	
}
