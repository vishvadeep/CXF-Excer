package com.cap.rest;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.eclipse.jetty.server.Request;
import org.springframework.stereotype.Service;

@Service("playerService")
public class PlayerServiceImpl implements IPlayerService {

	/**
	 * this method takes one argument from QueryParam and returns a Response
	 */
	public Response welcomePlayer(String playerName) {

		String greetMessage = "Welcome " + playerName + " to Lords - the home of cricket";
		return Response.status(200).entity(greetMessage).build();
	}

	/**
	 * this method takes three argument from QueryParam and returns a Response
	 */
	public Response getPlayerInfo(String playerName, int age, int matches) {

		String playerInfo = "[name=" + playerName +  ", age=" + age + ", matches=" + matches + "]";
		return Response.status(200).entity(playerInfo).build();
	}

	@Override
	public Response insert(String name, String pass, HttpServletRequest request,HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		
		String myJsfPage = "/index.jsp";
        String contextPath = request.getContextPath();
        
        response.sendRedirect(contextPath + myJsfPage);
        //return Response.status(Status.ACCEPTED).build();
        
		
		String greetMessage = "values updated  name1:" + name + " , name2 "+pass;
		System.out.println("insert" +greetMessage);
		return Response.status(200).entity(greetMessage).build();
	}

	@Override
	public Response update(String name, String pass) {
		// TODO Auto-generated method stub
		
		String greetMessage = "values updated  name1:" + name + " , name2 "+pass;
		
		System.out.println("update");
		return Response.status(401).entity(greetMessage).build();
		//return Response.status().build();
	}

	@Override
	public Response delete(String name, String pass) {
		// TODO Auto-generated method stub
		System.out.println("delete");
		
		String greetMessage = "values updated  name1:" + name + " , name2 "+pass;
		
		return Response.status(200).entity(greetMessage).build();
	}
}