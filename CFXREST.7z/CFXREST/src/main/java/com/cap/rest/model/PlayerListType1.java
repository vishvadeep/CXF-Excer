package com.cap.rest.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "playerType"
})
@XmlRootElement(name = "PlayerListType")

public class PlayerListType1 {
    @XmlElement(name = "PlayerType")
	List<PlayerType1> playerType = new ArrayList<>();

	public List<PlayerType1> getPlayerType() {
		return playerType;
	}

	public void setPlayerType(List<PlayerType1> playerType) {
		this.playerType = playerType;
	}
	
}
