package com.example.demo;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class JagsController {

	@GetMapping
	@RequestMapping("Data")
	public String getdata() {
		return "hello";
	}
	
	@GetMapping
	@RequestMapping("Data/a")
	public Student getstudent() {
		Student st = new Student();
		st.setAge("19");
		st.setName("name");
		return st;
	}
	
	@GetMapping
	@RequestMapping("Data/{name}")
	public Student getstudentname(@PathVariable(value="name") String name) {
		Student st = new Student();
		st.setAge("19");
		st.setName(name);
		return st;
	}
	
	
	@PostMapping
	@RequestMapping("Data/p")
	public Student setstudentname(@Valid @RequestBody Student st1) {
		System.out.println("student "+st1.getAge()+"name "+st1.getName());
		/*Student st = new Student();
		st.setAge("19");
		st.setName(name);*/
		return st1;
	}
	
}
