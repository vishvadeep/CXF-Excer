package com.pack.processor;

public class TransformationBean {

	public String makeUpperCase(String body) {
		System.out.println("you are in bean");
		String transformedBody = body.toUpperCase();
		System.out.println("body of bean " +transformedBody);
		return transformedBody;
		}
	
}
