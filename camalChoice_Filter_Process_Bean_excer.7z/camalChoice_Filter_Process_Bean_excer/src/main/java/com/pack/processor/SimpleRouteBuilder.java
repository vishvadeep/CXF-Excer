package com.pack.processor;

import org.apache.camel.builder.RouteBuilder;


public class SimpleRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		
		
		xmltojson();
		
		choiceLearning();
		processLearning();
		
		
		
	}
	
	
	public void xmltojson(){
		
		from("file:src/main/data?noop=true").filter()
        .method(new FilterJson())
		  .marshal().xmljson()
		  .to("file:target/messages/others/json?FileName=${file:name}.json");
		
	}

	public void choiceLearning(){
		from("file:src/main/data1?noop=true")
		.choice().when(xpath("//city = 'London'")).
		log("you are checking for london")
		.to("file:target/messages/uk")
		.otherwise().log("you are in otherwise").
		to("file:target/messages/others");
		
	}
	public void processLearning(){
		
		from("file:D:/inbox?noop=true").process(new MyProcessor()).
		bean(new TransformationBean(),"makeUpperCase")
		.unmarshal().csv().split(body().tokenize(","))
		.choice().when(body().contains("DVD"))
		.to("file:D:/outbox/DVD")
		.when(body().contains("CD")).
		  to("file:D:/outbox/CD");
	}
}
