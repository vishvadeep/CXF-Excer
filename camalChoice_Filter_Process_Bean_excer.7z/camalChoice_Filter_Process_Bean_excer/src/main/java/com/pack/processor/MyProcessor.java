package com.pack.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class MyProcessor  implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		System.out.println("you are in process");
		
		System.out.println("Received Order: " +
				exchange.getIn().getBody(String.class));
		
	}

}
